Tushar Nimbhorkar 11394110 & Diede Rusticus 10909486 <br />
Computer Vision '17 <br />
Artificial Intelligence Master <br />
University of Amsterdam
